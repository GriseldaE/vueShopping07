<script>
export default {
  props: {
    items: {
      type: Array,
      required: true,
    },
  },
};
</script>
<template>
  <div>
    <h2>Lista de Compras</h2>
    <ul>
      <li v-for="item in items" :key="item">{{ item }}</li>
    </ul>
  </div>
</template>