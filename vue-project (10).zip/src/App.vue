<script>
import ShoppingList from './List.vue';

export default {
  data() {
    return {
      listaDeArticulos: [
        'Papas',
        'soda',
        'chcolates',
        
      ],
    };
  },
  components: {
    ShoppingList,
  },
};
</script>

<template>
  <div>
    <shopping-list :items="listaDeArticulos"></shopping-list>
  </div>
</template>